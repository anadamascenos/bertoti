
    import java.util.Date;

    public class Emprestimo {
        private Livros livro;
        private String usuario;
        private boolean devolvido;
        private Date dataEmprestimo;
        private Date dataDevolucao;

        public Emprestimo(Livros livro, String usuario) {
            this.livro = livro;
            this.usuario = usuario;
            this.devolvido = false;
            this.dataEmprestimo = new Date();
            this.dataDevolucao = null;
        }

        public void devolverLivro() {
            this.devolvido = true;
            this.dataDevolucao = new Date();
        }

        public boolean estaDevolvido() {
            return this.devolvido;
        }

        public Livros getLivro() {
            return this.livro;
        }

        public String getUsuario() {
            return this.usuario;
        }

        public Date getDataEmprestimo() {
            return this.dataEmprestimo;
        }

        public Date getDataDevolucao() {
            return this.dataDevolucao;
        }
    }


